#!/usr/bin/env bash
# Rebuild the deck: base-v2.html -> out/pitch-deck-v4.html -> v5 -> v6 (the final deck). Needs Node 18+.
set -e; cd "$(dirname "$0")"; mkdir -p out
node 1-build-v4.js && node 2-posters-1-2.js && node 3-posters-rest.js
echo "Done: out/pitch-deck-v6.html"
